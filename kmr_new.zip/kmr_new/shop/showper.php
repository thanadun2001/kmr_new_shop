<?php 
    session_start();
    include('submit_rating.php'); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Khemarat - Ubon Ratchathani</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@200;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/mobile.css">
    <link rel="stylesheet" href="../css/web.css">
    <link rel="stylesheet" href="../shop/showstyle/style.css">
    <link rel="stylesheet" href="../shop/per/style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,1,0" />
<!-- เริ่ม link css ของ shop ตรงนี้ -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<script src="js/main.js"></script>
<!-- link script commet  -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
 <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<body>
 <!-- Top Navigation Menu -->
 <nav class="sticky">
    <div class="contentarea">
        <div class="logo">
            <div>
                <img src="../img/logo2.png" alt="logo">
            </div>
            <div>
                <p>ฟื้นใจเมืองเขมราฐ<br>KHEMARAT</p>
            </div>
        </div>            
        <!-- Navigation links (hidden by default) -->
        <div class="mainnav" id="menuLinks">
            <ul class="navweb">
                <li><a href="../index.html">หน้าหลัก</a></li>
                <li><a href="../aboutus.html">เกี่ยวกับเรา</a></li>
                <li><a href="../map.html">แผนที่ทางวัฒนธรรม</a></li>
                <li><a href="shop.php"  class="active">สินค้าและบริการ</a></li>
                <li><a href="../localmedia.html">ชุดความรู้และสื่อสารสนเทศ</a></li>
            </ul>
            <ul class="membernav">
                <li><a href="#"><img src="../img/facebook.png"></a></li>
                <li><a href="" type="button" data-toggle="modal" data-target="#exampleModal" ><img src="../img/member.png"></a></li>
            </ul>
        </div>

        <div id="menuHam">
            <!--<a href="javascript:void(0);" class="icon" onclick="myFunction()">-->
            <input type="checkbox" id="checkbox4" class="checkbox4 visuallyHidden">
            <label for="checkbox4">
                <div class="hamburger hamburger4">
                    <span class="bar bar1"></span>
                    <span class="bar bar2"></span>
                    <span class="bar bar3"></span>
                    <span class="bar bar4"></span>
                    <span class="bar bar5"></span>
                </div>
            </label>
            <!--</a>-->
        </div>
    </div>
</nav>
<!-- เริ่มส่วนของเนื้อหาตรงนี้ -->
<section>
  <main>
    <div class="card">
      <div class="card__title">
        <div class="icon">
          <a href="store.php"><i class="fa fa-arrow-left"></i></a>
        </div>
        <h3>New products</h3>
      </div>
      <div class="card__body">
        <div class="half">
          <div class="featured_text">
            <h1>Nurton</h1>
            <p class="sub">Office Chair</p>
            <p class="price">$210.00</p>
          </div>
          <div class="image">
            <img src="../img/st1.jpg" alt="">
          </div>
        </div>
        <div class="half">
          <div class="description">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero voluptatem nam pariatur voluptate perferendis, asperiores aspernatur! Porro similique consequatur, nobis soluta minima, quasi laboriosam hic cupiditate perferendis esse numquam magni.</p>
          </div>
          <span class="stock"><i class="fa fa-pen"></i> In stock</span>
          <div class="reviews">
            <ul class="stars">
              <li><i class="fa fa-star"></i></li>
              <li><i class="fa fa-star"></i></li>
              <li><i class="fa fa-star"></i></li>
              <li><i class="fa fa-star"></i></li>
              <li><i class="fa fa-star-o"></i></li>
            </ul>
            <span>(64 reviews)</span>
          </div>
        </div>
      </div>
      <div class="card__footer">
        <div class="action">
          <p><a href="formper.php" type="button"><button>Pre-Order</button></p></a>
        </div>
      </div>
    </div>
  </main>
<!-- code ตัวคอมเมนต์-->
  <div class="container">
    	<div class="card">
    		<div class="card-header">Review Product</div>
    		<div class="card-body">
    			<div class="row">
    				<div class="col-sm-4 text-center">
    					<h1 class="text-warning mt-4 mb-4">
    						<b><span id="average_rating">0.0</span> / 5</b>
    					</h1>
    					<div class="mb-3">
    						<i class="fa fa-star star-light mr-1 main_star"></i>
                            <i class="fa fa-star star-light mr-1 main_star"></i>
                            <i class="fa fa-star star-light mr-1 main_star"></i>
                            <i class="fa fa-star star-light mr-1 main_star"></i>
                            <i class="fa fa-star star-light mr-1 main_star"></i>
	    				</div>
    					<h3><span id="total_review">0</span> Review</h3>
    				</div>
    				<div class="col-sm-4">
    					<p>
                            <div class="progress-label-left"><b>5</b> <i class="fa fa-star text-warning"></i></div>
                            <div class="progress-label-right">(<span id="total_five_star_review">0</span>)</div>
                            <div class="progress">
                                <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="five_star_progress"></div>
                            </div>
                        </p>
    					<p>
                            <div class="progress-label-left"><b>4</b> <i class="fa fa-star text-warning"></i></div>
                            <div class="progress-label-right">(<span id="total_four_star_review">0</span>)</div>
                            <div class="progress">
                                <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="four_star_progress"></div>
                            </div>               
                        </p>
    					<p>
                            <div class="progress-label-left"><b>3</b> <i class="fa fa-star text-warning"></i></div>                          
                            <div class="progress-label-right">(<span id="total_three_star_review">0</span>)</div>
                            <div class="progress">
                                <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="three_star_progress"></div>
                            </div>               
                        </p>
    					<p>
                            <div class="progress-label-left"><b>2</b> <i class="fa fa-star text-warning"></i></div>                          
                            <div class="progress-label-right">(<span id="total_two_star_review">0</span>)</div>
                            <div class="progress">
                                <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="two_star_progress"></div>
                            </div>               
                        </p>
    					<p>
                            <div class="progress-label-left"><b>1</b> <i class="fa fa-star text-warning"></i></div>               
                            <div class="progress-label-right">(<span id="total_one_star_review">0</span>)</div>
                            <div class="progress">
                                <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="one_star_progress"></div>
                            </div>               
                        </p>
    				</div>
                    <!-- code แสดงตัวใส่ข้อมูล -->
    				<div class="col-sm-4 text-center">
    					<h3 class="mt-4 mb-3">Write Review Here</h3>
    					<button type="button" name="add_review" id="add_review" class="btn btn-primary">Review</button>
    				</div>
    			</div>
    		</div>
    	</div>
    	<div class="mt-5" id="review_content"></div>
    </div>
</body>
</html>

<div id="review_modal" class="modal" tabindex="-1" role="dialog">
  	<div class="modal-dialog" role="document">
    	<div class="modal-content">
	      	<div class="modal-header">
	        	<h5 class="modal-title">Submit Review</h5>
	        	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          		<span aria-hidden="true">&times;</span>
	        	</button>
	      	</div>
	      	<div class="modal-body">
	      		<h4 class="text-center mt-2 mb-4">
	        		<i class="fa fa-star star-light submit_star mr-1" id="submit_star_1" data-rating="1"></i>
                    <i class="fa fa-star star-light submit_star mr-1" id="submit_star_2" data-rating="2"></i>
                    <i class="fa fa-star star-light submit_star mr-1" id="submit_star_3" data-rating="3"></i>
                    <i class="fa fa-star star-light submit_star mr-1" id="submit_star_4" data-rating="4"></i>
                    <i class="fa fa-star star-light submit_star mr-1" id="submit_star_5" data-rating="5"></i>
	        	</h4>
	        	<div class="form-group">
	        		<input type="text" name="user_name" id="user_name" class="form-control" placeholder="Enter Your Name" />
	        	</div>
	        	<div class="form-group">
	        		<textarea name="user_review" id="user_review" class="form-control" placeholder="Type Review Here"></textarea>
	        	</div>
	        	<div class="form-group text-center mt-4">
	        		<button type="button" class="btn btn-primary" id="save_review">Submit</button>
	        	</div>
	      	</div>
    	</div>
  	</div>
</div>
<!-- ถึงตรงนี้ -->
 </section>
           </div>
       </div>
    </div>
    <!-- script ตัวคอมเมนต์-->
<script>
    $(document).ready(function(){
      var rating_data = 0;

    $('#add_review').click(function(){
        $('#review_modal').modal('show');
    });

    $(document).on('mouseenter', '.submit_star', function(){

        var rating = $(this).data('rating');

        reset_background();

        for(var count = 1; count <= rating; count++)
        {
            $('#submit_star_'+count).addClass('text-warning');
        }

    });

    function reset_background()
    {
        for(var count = 1; count <= 5; count++)
        {
            $('#submit_star_'+count).addClass('star-light');
            $('#submit_star_'+count).removeClass('text-warning');
        }
    }

    $(document).on('mouseleave', '.submit_star', function(){

        reset_background();

        for(var count = 1; count <= rating_data; count++)
        {
            $('#submit_star_'+count).removeClass('star-light');
            $('#submit_star_'+count).addClass('text-warning');
        }

    });

    $(document).on('click', '.submit_star', function(){
        rating_data = $(this).data('rating');

    });

    $('#save_review').click(function(){

        var user_name = $('#user_name').val();
        var user_review = $('#user_review').val();

        if(user_name == '' || user_review == '')
        {
            alert("Please Fill Both Field");
            return false;
        }
        else
        {
            $.ajax({
                url:"submit_rating.php",
                method:"POST",
                data:{rating_data:rating_data, user_name:user_name, user_review:user_review},
                success:function(data)
                {
                    $('#review_modal').modal('hide');

                    load_rating_data();

                    alert(data);
                }
            })
        }

    });
    $('#save_review').click(function(){
      var user_name = $('#user_name').val();
      var user_review = $('#user_review').val();

        if(user_name == '' || user_review == '')
          {
              alert("Please Fill Both Field");
              return false;
          }
         else
          {
          $.ajax({
             url:"submit_rating.php",
             method:"POST",
             data:{rating_data:rating_data, user_name:user_name, user_review:user_review},
             success:function(data)
        {
            $('#review_modal').modal('hide');
            load_rating_data();
            alert(data);
        }
    })
}

});

load_rating_data();

function load_rating_data()
{
$.ajax({
    url:"submit_rating.php",
    method:"POST",
    data:{action:'load_data'},
    dataType:"JSON",
    success:function(data)
    {
        $('#average_rating').text(data.average_rating);
        $('#total_review').text(data.total_review);

        var count_star = 0;

        $('.main_star').each(function(){
            count_star++;
            if(Math.ceil(data.average_rating) >= count_star)
            {
                $(this).addClass('text-warning');
                $(this).addClass('star-light');
            }
        });

        $('#total_five_star_review').text(data.five_star_review);
        $('#total_four_star_review').text(data.four_star_review);
        $('#total_three_star_review').text(data.three_star_review);
        $('#total_two_star_review').text(data.two_star_review);
        $('#total_one_star_review').text(data.one_star_review);
        $('#five_star_progress').css('width', (data.five_star_review/data.total_review) * 100 + '%');
        $('#four_star_progress').css('width', (data.four_star_review/data.total_review) * 100 + '%');
        $('#three_star_progress').css('width', (data.three_star_review/data.total_review) * 100 + '%');
        $('#two_star_progress').css('width', (data.two_star_review/data.total_review) * 100 + '%');
        $('#one_star_progress').css('width', (data.one_star_review/data.total_review) * 100 + '%');

        if(data.review_data.length > 0)
        {
            var html = '';

            for(var count = 0; count < data.review_data.length; count++)
            {
                html += '<div class="row mb-3">';
                html += '<div class="col-sm-1"><div class="rounded-circle bg-danger text-white pt-2 pb-2"><h3 class="text-center">'+data.review_data[count].user_name.charAt(0)+'</h3></div></div>';
                html += '<div class="col-sm-11">';
                html += '<div class="card">';
                html += '<div class="card-header"><b>'+data.review_data[count].user_name+'</b></div>';
                html += '<div class="card-body">';

                for(var star = 1; star <= 5; star++)
                {
                    var class_name = '';
                    if(data.review_data[count].rating >= star)
                    {
                        class_name = 'text-warning';
                    }
                    else
                    {
                        class_name = 'star-light';
                    }

                    html += '<i class="fas fa-star '+class_name+' mr-1"></i>';
                }

                html += '<br />';
                html += data.review_data[count].user_review;
                html += '</div>';
                html += '<div class="card-footer text-right">On '+data.review_data[count].datetime+'</div>';
                html += '</div>';
                html += '</div>';
                html += '</div>';
            }

            $('#review_content').html(html);
        }
    }
})
}

       if($( window ).width() < 768){
               $("#menuLinks").hide();
               $("#titlebox").addClass("card");
           } else {
               $("#menuLinks").show();
               $("#checkbox4").hide();
           }
       $( window ).resize(function() {
           if($( window ).width() < 768){
               $("#menuLinks").hide();
               $("#checkbox4").prop("checked",false);
               $("#titlebox").addClass("card");
           } else {
               $("#menuLinks").show();
               $("#checkbox4").hide();
               $("#checkbox4").prop("checked",false);
               $("#titlebox").removeClass("card");
           }
       });
       $("#checkbox4").click(function() {
           if($(this).is(":checked")) {
               $("#menuLinks").show(300);
           } else {
               $("#menuLinks").hide(200);
           }
       });
   });
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  });
}
</script> 

   <footer>
    <p>โครงการพัฒนาเว็บไซต์แผนที่ทางวัฒนธรรม <br>อำเภอเขมราฐ จังหวัดอุบลราชธานี</p>
    <p>Copyrighted 2023 all rights reserved <br>by Ubon Ratchathani University.<br>
    Design by <a href="http://www.austystudio.com">AustyStudio</a></p>
</footer>
</body>
</html>
