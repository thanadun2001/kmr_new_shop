
<?php 

define('DB_SERVER', 'localhost'); // Your hostname
define('DB_USER', 'root'); // Database Username
define('DB_PASS', ''); // Database Password
define('DB_NAME', 'project'); // Database Name
function connectDB()
{

        $conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
            $dbcon = $conn;
            mysqli_set_charset($conn, "utf8");
            return $conn;

}

?>
