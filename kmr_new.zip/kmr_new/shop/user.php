<?php
session_start();
if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: shop.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Khemarat - Ubon Ratchathani</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@200;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <link rel="stylesheet" href="../css/mobile.css">
    <link rel="stylesheet" href="../css/web.css">
    <link rel="stylesheet" href="../shop/sh_style/style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,1,0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
<!-- เริ่ม link css ของ shop ตรงนี้ -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<script src="js/main.js"></script>
</head>


<body>
<nav class="sticky">
    <div class="contentarea">
        <div class="logo">
            <div>
                <img src="../img/logo2.png" alt="logo">
            </div>
            <div>
                <p>ฟื้นใจเมืองเขมราฐ<br>KHEMARAT</p>
            </div>
        </div>            
        <!-- Navigation links (hidden by default) -->
        <div class="mainnav" id="menuLinks">
            <ul class="navweb">
                <li><a href="../index.html">หน้าหลัก</a></li>
                <li><a href="../aboutus.html">เกี่ยวกับเรา</a></li>
                <li><a href="../map.html">แผนที่ทางวัฒนธรรม</a></li>
                <li><a href="shop.php"  class="active">สินค้าและบริการ</a></li>
                <li><a href="../localmedia.html">ชุดความรู้และสื่อสารสนเทศ</a></li>
            </ul>
            <ul class="membernav">
                <li><a href="#"><img src="../img/facebook.png"></a></li>
                <li><a href="" type="button" data-toggle="modal" data-target="#exampleModal" ><img src="../img/member.png"></a></li>
            </ul>
        </div>

        <div id="menuHam">
            <!--<a href="javascript:void(0);" class="icon" onclick="myFunction()">-->
            <input type="checkbox" id="checkbox4" class="checkbox4 visuallyHidden">
            <label for="checkbox4">
                <div class="hamburger hamburger4">
                    <span class="bar bar1"></span>
                    <span class="bar bar2"></span>
                    <span class="bar bar3"></span>
                    <span class="bar bar4"></span>
                    <span class="bar bar5"></span>
                </div>
            </label>
            <!--</a>-->
        </div>
    </div>
</nav>

    <div class="container">
        <div class="bg-light p-5 rounded mt-3">
            <h1>สวัสดี <?php echo $user['username']; ?></h1>
            <h2>ระดับผู้ใช้ <?php echo $user['level']; ?></h2>
            <div class="mt-5">
                <?php if ($user['level'] == 'administrator') { // แสดงลิงค์ไปยังหน้าผู้ดูแลระบบเมื่อผู้ใช้เป็นแอดมิน ?>
                    <a href="admin.php" class="btn btn-lg btn-warning">หน้าสำหรับผู้ดูแลระบบ</a>
                <?php } ?>
                <?php if ($user['level'] == 'employee') { // แสดงลิงค์ไปยังหน้าผู้ประกอบการเมื่อผู้ใช้เป็นผู้ประกอบการ ?>
                    <a href="employee.php" class="btn btn-lg btn-success">หน้าสำหรับผู้ประกอบการ</a>
                <?php } ?>
                <?php if ($user['level'] == 'user') { // แสดงลิงค์ไปยังหน้าผู้ใช้เมื่อผู้ใช้เป็นuser ?>
                    <a href="user1.php" class="btn btn-lg  btn-info">หน้าสำหรับผู้ใช้</a>
                <?php } ?>

                <a href="logout_action.php" class="btn btn-lg btn-danger">ออกจากระบบ</a>
            </div>
        </div>
    </div>
    <script>
    $(document).ready(function(){
       if($( window ).width() < 768){
               $("#menuLinks").hide();
               $("#titlebox").addClass("card");
           } else {
               $("#menuLinks").show();
               $("#checkbox4").hide();
           }
       $( window ).resize(function() {
           if($( window ).width() < 768){
               $("#menuLinks").hide();
               $("#checkbox4").prop("checked",false);
               $("#titlebox").addClass("card");
           } else {
               $("#menuLinks").show();
               $("#checkbox4").hide();
               $("#checkbox4").prop("checked",false);
               $("#titlebox").removeClass("card");
           }
       });
       $("#checkbox4").click(function() {
           if($(this).is(":checked")) {
               $("#menuLinks").show(300);
           } else {
               $("#menuLinks").hide(200);
           }
       });
   });
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  });
}

</script> 

   <footer>
    <p>โครงการพัฒนาเว็บไซต์แผนที่ทางวัฒนธรรม <br>อำเภอเขมราฐ จังหวัดอุบลราชธานี</p>
    <p>Copyrighted 2023 all rights reserved <br>by Ubon Ratchathani University.<br>
    Design by <a href="http://www.austystudio.com">AustyStudio</a></p>
</footer>
</body>

</html>