<?php 

session_start(); // เปิดใช้งาน session
if (isset($_SESSION['user_login'])) { // ถ้าเข้าระบบอยู่
    header("location: user.php"); // redirect ไปยังหน้า index.php
    exit;
}

include_once("fuction.php");
$conn = connectDB(); // เชื่อมต่อฐานข้อมูล
$username = mysqli_real_escape_string($conn, $_POST['username']); // รับค่า username
$password = mysqli_real_escape_string($conn, $_POST['password']); // รับค่า password

$strSQL = "SELECT * FROM user WHERE u_username = '$username' AND u_password = md5('$password')";
$Query = mysqli_query($conn, $strSQL);
$row = mysqli_num_rows($Query);
if($row) {
    $res = mysqli_fetch_assoc($Query);
    $_SESSION['user_login'] = array(
        'id' => $res['u_id'],
        'username' => $res['u_username'],
        'level' => $res['u_level']
    );
    echo '<script>alert("ยินดีต้อนรับคุณ ', $res['u_username'],'");window.location="user.php";</script>';
} else {
    echo '<script>alert("username หรือ password ไม่ถูกต้อง!!");window.location="shop.php";</script>';
}
  

?>