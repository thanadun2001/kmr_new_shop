<?php
include_once('fuction.php');
$conn = connectDB();

$data = $_POST;
$u_email = $data['u_email'];
$u_username = $data['u_username'];
$u_password = md5($data['u_password']); // เข้ารหัสด้วย md5
$u_level = $data['u_level'];

$strSQL = "INSERT INTO 
user(
    `u_email`,
    `u_username`,
    `u_password`, 
    `u_level`
) VALUES (
    '$u_email', 
    '$u_username', 
    '$u_password', 
    '$u_level'
)";

$Query = mysqli_query($conn, $strSQL) or die(mysqli_error($conn));
if ($Query) {
    echo '<script>alert("ลงทะเบียนเรียบร้อยแล้ว");window.location="shop.php";</script>';
} else {
    echo '<script>alert("พบข้อผิดพลาด");window.location="formreg.php";</script>';
}
?>


