<?php 
session_start();
include('fuction.php'); 

// File upload path
$targetDir = "uploads/";

if (isset($_POST['submit'])) {
    if (!empty($_FILES["file"]["name"])){      
    

    }
    $store = mysqli_real_escape_string($conn, $_POST['store']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $tel = mysqli_real_escape_string($conn, $_POST['tel']);
    $product = mysqli_real_escape_string($conn, $_POST['product']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $fileName = basename($_FILES["file"]["name"]);
        
        $targetFilePath = $targetDir. $fileName;
        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

        // Allow certain file formats
        $allowTypes = array('jpg', 'png', 'jpeg', 'gif', 'pdf');
        if (in_array($fileType, $allowTypes)) {
            if (move_uploaded_file($_FILES['file']['tmp_name'], $targetFilePath)) {
                $insert = $conn->query("INSERT INTO images(store,email,tel,product,description,price, file_name, uploaded_on) VALUES ('$store','$email','$tel','$product','$description','$price','".$fileName."', NOW())");         
                if ($insert) {
                    $_SESSION['statusMsg'] = "The file <b>"  .$fileName . "</b> has been uploaded successfully.";
                    header("location: showst.php");
                } else {
                    $_SESSION['statusMsg'] = "File upload failed, please try again.";
                    header("location: showst.php");
                }
            } else {
                $_SESSION['statusMsg'] = "Sorry, there was an error uploading your file.";
                header("location: showst.php");
            }
        } else {
            $_SESSION['statusMsg'] = "Sorry, only JPG, JPEG, PNG & GIF files are allowed to upload.";
            header("location: showst.php");
        }
    } else {
        $_SESSION['statusMsg'] = "Please select a file to upload.";
        header("location: showst.php");
    }


?>