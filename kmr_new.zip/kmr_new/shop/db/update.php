<?php
  include('fuction.php');
  include('showsh.php');
  if(isset($_POST['update']))
  {   
      $id =$_POST['id'];
      $store = $_POST['store'];
      $username =$_POST['username'];
      $email = $_POST['email'];
      $tel = $_POST['tel'];
      $address = $_POST['address'];
      $file_Name = basename($_FILES["file"]["name"]);
      
      $targetDir = "uploads/";

      $targetFilePath = $targetDir. $file_Name;
      $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

        // Allow certain file formats
        $allowTypes = array('jpg', 'png', 'jpeg', 'gif', 'pdf');
        if (in_array($fileType, $allowTypes)) {
            if (move_uploaded_file($_FILES['file']['tmp_name'], $targetFilePath)) {  
              $update = $conn->query ("UPDATE shop SET 
              file_name = '$file_Name' WHERE id = '$id'
             "); 
            }        
          }

      $update_product_query ="UPDATE shop SET 
      store='$store',
      username='$username',
      email='$email',
      tel='$tel',
      address='$address'
      WHERE id ='$id'";
   
      $update_product_query_run = mysqli_query($conn,$update_product_query);
}
 
?>