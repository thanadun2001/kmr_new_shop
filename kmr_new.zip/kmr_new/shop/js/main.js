$(window).on("scroll", function () {
    var parallax = $(".parallax");
    var scrollPosition = $(this).scrollTop();
    parallax.css("transform", "translateY(" + scrollPosition * 0.5 + "px" + ")");
  });
  $(document).ready(function(){
    
    $('.card').click(function(){
        $('#pageModal').modal('toggle');
        var bodyCard =$(this).html();
        $(".modal-body").html(bodyCard);
    });

});

$("#loginBtn").on('click',function(){
  $('#RegLi').removeClass('active');
  $('#loginLi').addClass('active');
})
$("#regBtn").on('click',function(){
   $('#loginLi').removeClass('active');
   $('#RegLi').addClass('active');
})
$('.btn-toggle').click(function() {
  $(this).find('.btn').toggleClass('active');  
  
  if ($(this).find('.btn-primary').size()>0) {
    $(this).find('.btn').toggleClass('btn-primary');
  }
  if ($(this).find('.btn-danger').size()>0) {
    $(this).find('.btn').toggleClass('btn-danger');
  }
  if ($(this).find('.btn-success').size()>0) {
    $(this).find('.btn').toggleClass('btn-success');
  }
  if ($(this).find('.btn-info').size()>0) {
    $(this).find('.btn').toggleClass('btn-info');
  }
  
  $(this).find('.btn').toggleClass('btn-default');})